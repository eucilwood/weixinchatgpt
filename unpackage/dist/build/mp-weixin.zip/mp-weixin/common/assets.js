"use strict";exports._imports_0="/static/hm.png";
